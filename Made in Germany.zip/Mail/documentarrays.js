
var zDokumentText=new Array(22);
var zQuelle=new Array(22);
var zTitel=new Array(22);

/* was sind zDokumentText[3] und [4] - wann wird das gebraucht? */
zDokumentText[0]="";

zDokumentText[3]="Wie ein Pressesprecher von Mauermetall gestern erklärte, ist es in einer "+
					"firmeneigenen Erzmine zu einem Unglück gekommen, bei dem 41 Menschen starben "+
					"und mehr als 200 verletzt wurden. Grund dafür waren Sicherheitslücken, "+
					"für die Mayermetall verantwortlich war. Wie es dazu kommen konnte und warum "+
					"die Hamburger Verantwortlichen nicht darüber in Kenntnis gesetzt wurden, "+
					"dazu konnte er noch keine Auskunft geben. "+
					"Aufklärung und Fürsorge, so hieß es, stünden nun vor Ort im Vordergrund.";
zDokumentText[4]="Wie Wolfgang Maria Mayer uns gestern in einem Interview berichtete, ist es "+
					"in einer firmeneigenen Erzmine zu einem Unglück gekommen, bei dem 41 Menschen "+
					"starben und mehr als 200 verletzt wurden. Grund dafür waren Sicherheitslücken, "+
					"für die Mayermetall verantwortlich war. Wie es dazu kommen konnte und "+
					"warum die Hamburger Verantwortlichen nicht darüber in Kenntnis gesetzt "+
					"wurden, dazu konnte er keine noch Auskunft geben. "+
					"Aufklärung und Fürsorge, so erklärte er, stünden nun vor Ort im Vordergrund. ";
zDokumentText[7]="Sicherheitslücken bei Mayermetall! Im Interview gab Wolfgang "+
 					"Maria Mayer nun zu, dass es signifikante Sicherheitsmängel "+
 					"in der verunglückten Mine gab. Wie es dazu kommen konnte und "+
 					"warum die Hamburger Verantwortlichen nicht darüber in Kenntnis gesetzt "+
 					"wurden, dazu konnte er keine Auskunft geben. Beim Unglück im vergangenen "+
 					"Monat kamen 41 Menschen ums Leben, mehr als 200 wurden verletzt.";
zDokumentText[9]="Mayermetall-Unglück weiterhin ungeklärt! Im Interview erklärte Wolfgang "+
					"Maria Mayer nun, dass es keinerlei Sicherheitsmängel in der verunglückten "+
					"Mine gegen habe. Nach ausgiebigen internen Untersuchungen bleibt die "+
					"Unfallursache weiterhin ungeklärt. Beim Unglück im vergangenen Monat "+
					"kamen 41 Menschen ums Leben, mehr als 200 wurden verletzt. ";
zDokumentText[12]="Sicherheitslücken bei Mayermetall! Im Interview gab Wolfgang "+
 					"Maria Mayer nun zu, dass es signifikante Sicherheitsmängel "+
 					"in der verunglückten Mine gabt. Wie es dazu kommen konnte und "+
 					"warum die Hamburger Verantwortlichen nicht darüber in Kenntnis gesetzt "+
 					"wurden, dazu konnte er keine Auskunft geben. Beim Unglück im vergangenen " +
 					"Monat kamen 41 Menschen ums Leben, mehr als 200 wurden verletzt.";
zDokumentText[13]="Mayermetall-Unglück weiterhin ungeklärt! Im Interview erklärte Wolfgang "+
					"Maria Mayer nun, dass es keinerlei Sicherheitsmängel in der verunglückten "+
					"Mine gegen habe. Nach ausgiebigen internen Untersuchungen bleibt die "+
					"Unfallursache weiterhin ungeklärt. Beim Unglück im vergangenen Monat "+
					"kamen 41 Menschen ums Leben, mehr als 200 wurden verletzt. ";
zDokumentText[14]="Mayermetall-Skandal! Nun ist klar: Die Sicherheitslücken waren den "+
					"Hamburger Verantwortlichen bekannt - 41 Menschen kamen ums Leben, "+
					"mehr als 200 wurden verletzte und Wolfgang Maria Mayer übernimmt nach "+
					"wie vor keinerlei Verantwortung.";
zDokumentText[19]="„Die Mayermetall GmbH freut sich außerordentlich verkünden zu dürfen, dass "+ 
					"der langjährige Kollege Herr Heinz Bartelsmann zum 1. September die Stelle des Personalchefs übernehmen wird.“ "+
					"Mit diesen Worten verrät Pressesprecher Knoll, was Viele erwartet haben. Durch seine "+
					"konsequente und sichere Leitung führte er seine Abteilung stets zu Wachstum und überzeugte mit langem Atem. "+
					"Dem pensionierten Herrn Mutmacher wünscht die IndustrieMarkt-Redaktion einen lebhaften und ausgeglichenen Ruhestand! ";
zDokumentText[20]="„Die Mayermetall GmbH freut sich außerordentlich verkünden zu dürfen, "+
					"dass Herr Markus Schmitz zum 1. September die Stelle des Personalchefs übernehmen wird.“ "+
					"Mit diesen Worten verrät Pressesprecher Knoll, was nur Wenige erwartet haben. "+
					"Schmitz führte in den vergangen Jahren erfolgreich die Personalabteilung bei der "+ 
					"Süderholz in Berlin-Spandau. Innovatives Personalmanagement trifft hier auf "+
					"hanseatische Tradition - eine gewagte, doch sicher geplante Kombination. "+
					"Dem pensionierten Herrn Mutmacher wünscht die IndustrieMarkt-Redaktion "+
					"einen lebhaften und ausgeglichenen Ruhestand! ";

zQuelle[0]="";					
					
zQuelle[3]="Zeitung des Nordens";
zQuelle[4]="Zeitung des Nordens";
zQuelle[7]="Stader Morgenblatt";
zQuelle[9]="Stader Morgenblatt";
zQuelle[12]="Hamburger Abendpost";
zQuelle[13]="Hamburger Abendpost";
zQuelle[14]="Norddeutsche Zeitung";

zQuelle[19]="IndustrieMarkt";
zQuelle[20]="IndustrieMarkt";

zTitel[0]="";

zTitel[3]="Sicherheitslücken bei Mayermetall";
zTitel[4]="Sicherheitslücken bei Mayermetall";
zTitel[7]="Mayermetall war an Sicherheitslücken in Erzmine beteiligt";
zTitel[9]="Mayermetall streitet Sicherheitslücken in Erzminen ab";
zTitel[12]="Mayermetall war an Sicherheitslücken in Erzmine beteiligt";
zTitel[13]="Mayermetall streitet Sicherheitslücken in Erzminen ab";
zTitel[14]="Mayermetall verheimlicht Unglück in Erzmine";

zTitel[19]="Neuer Personalchef bei Mayermetall";
zTitel[20]="Neuer Personalchef bei Mayermetall";
